helllo !
@extends('default.footer')
@section('content')
<div class="content">
    <div class="row">
        <div class="col-lg-12">
            Home
            <h1>test</h1>
        </div>
    </div>
</div>
@endsection
@section('scripts')
@parent
@endsection
@extends('default.header')