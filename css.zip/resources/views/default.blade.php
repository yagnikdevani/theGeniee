@include('header')
{!! Form::open(['url' => 'foo/bar']) !!}
{!! Form::close() !!}
@include('footer')
    