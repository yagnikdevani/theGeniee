<div id="bottom-footer" class="hidden-xs">
    <div class="container">
      <div class="row">
        <div class="col-md-4">
          <div class="footer-left">
            &copy; 
            <div class="credits">
              Designed by <a href="#"></a>
            </div>
          </div>
        </div>

        <div class="col-md-8">
          <div class="footer-right">
            <ul class="list-unstyled list-inline pull-right">
              <li><a href="{{ url('/') }}">Home</a></li>
              <li><a href="#about">About</a></li>
              <li><a href="#service">Service</a></li>
              <li><a href="#portfolo">Portfolio</a></li>
              <li><a href="#contact">Contact</a></li>
            </ul>
          </div>
        </div>
      </div>
    </div>
  </div>
  <script src="js/default/jquery.min.js"></script>
  <script src="js/default/bootstrap.min.js"></script>
  <script src="js/default/jquery.flexslider.js"></script>
  <script src="js/default/jquery.inview.js"></script>
  <script src="js/default/script.js"></script>
  <script src="js/default/contactform/contactform.js"></script>
</body>
</html>
